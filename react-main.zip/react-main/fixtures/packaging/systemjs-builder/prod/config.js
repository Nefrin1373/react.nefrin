System.config({
  paths: {
    react:
      '../../../../build/oss-experimental/react/umd/react.production.min.js',
    'react-dom':
      '../../../../build/oss-experimental/react-dom/umd/react-dom.production.min.js',
    schedule:
      '../../../../build/oss-experimental/scheduler/umd/schedule.development',
  },
});
