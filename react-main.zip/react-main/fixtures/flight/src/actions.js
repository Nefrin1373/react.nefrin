'use server';

export async function like() {
  return new Promise((resolve, reject) => resolve('Liked'));
}
